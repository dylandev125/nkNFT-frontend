import PropTypes from 'prop-types';
// @mui
import { alpha, useTheme, styled } from '@mui/material/styles';
import { Box, Grid, Divider, Card, CardHeader, CardContent, Container, Typography, LinearProgress, Accordion, AccordionSummary, AccordionDetails } from '@mui/material';
// hooks
import useResponsive from '../../hooks/useResponsive';
// utils
import { fPercent } from '../../utils/formatNumber';
// _mock_
import { _skills } from '../../_mock';
// components
import Image from '../../components/Image';
import Iconify from '../../components/Iconify';
import { MotionInView, varFade } from '../../components/animate';
// import Accordion from '@mui/material/Accordion';
// import AccordionSummary from '@mui/material/AccordionSummary';
// import AccordionDetails from '@mui/material/AccordionDetails';
// // import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
// import CarouselBasic1 from '../../pages/overview/extra/carousel/CarouselBasic1';

// ----------------------------------------------------------------------

const RootStyle = styled('div')(({ theme }) => ({
  textAlign: 'center',
  paddingTop: theme.spacing(20),
  paddingBottom: theme.spacing(10),
  [theme.breakpoints.up('md')]: {
    textAlign: 'left',
  },
}));

const AccordionStyle = styled('p')(({ theme }) => ({
  fontWeight: '500',
  fontSize: '30px',
  lineHeight: '140%',
  color: 'transparent',
  background: 'linear-gradient(110.52deg, #FF7C03 13.88%, #FFD500 123.38%)',
  backgroundClip: 'text',
  marginBottom: '40px',
  marginTop: '40px',
  textTransform: 'uppercase',
  WebkitBackgroundClip: 'text'
}))

const AccordionTitleStyle = styled("Typography")(({ theme }) => ({
  color: 'transparent',
  fontSize: '16px',
  background: 'linear-gradient(110.52deg, #FF7C03 13.88%, #FFD500 123.38%)',
  backgroundClip: 'text',
  WebkitBackgroundClip: 'text'
}))

const CardStyle = styled("Card")(() => ({
  background: 'rgba(35, 20, 71, .57)',
  borderRadius: '12px',
  padding: '33px 48px 28px'
}))

const AnchorStyle = styled("a")(() => ({
  textDecoration: 'none',
  cursor: 'pointer',
  color: '#fff',
  '&:hover': {
    color: 'transparent',
    background: 'linear-gradient(110.52deg, #FF7C03 13.88%, #FFD500 123.38%)',
    backgroundClip: 'text',
    WebkitBackgroundClip: 'text'
  }
}))

// ----------------------------------------------------------------------

export default function AboutWhat() {
  const theme = useTheme();

  const isDesktop = useResponsive('up', 'md');

  const isLight = theme.palette.mode === 'light';
  const shadow = `-40px 40px 80px ${alpha(isLight ? theme.palette.grey[500] : theme.palette.common.black, 0.48)}`;

  return (
    <RootStyle>
      <Container>
        <Grid container spacing={3}>
          {isDesktop && (
            <Grid item xs={12} md={3} lg={4} sx={{ pr: { md: 7 } }}>
              <Grid container spacing={3} alignItems="flex-end">
                <Grid item xs={12}>
                  <MotionInView variants={varFade().inUp} >
                    <div sx={{ position: 'sticky', top: '0px' }}>
                      <Card sx={{ textAlign: 'center' }}>
                        <CardHeader
                          title="NAVIGATION"
                        />
                        <Divider sx={{ paddingTop: 3 }} />
                        <CardContent>
                          <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'left', padding: 1 }}>
                            <img src="arrow.svg" alt="" />
                            <AnchorStyle href="#about" >
                              <Typography sx={{ padding: '0px 15px 0px 15px' }}>About</Typography>
                            </AnchorStyle>
                          </Box>

                          <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'left', padding: 1 }}>
                            <img src="arrow.svg" alt="" />
                            <AnchorStyle href="#lifeAtNeko">
                              <Typography sx={{ padding: '0px 15px 0px 15px' }} >
                                Start your life in the Nekotopia
                              </Typography>
                            </AnchorStyle>
                          </Box>


                          <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'left', padding: 1 }}>
                            <img src="arrow.svg" alt="" />
                            <AnchorStyle href="#lifeAtNeko">
                              <Typography sx={{ padding: '0px 15px 0px 15px' }}>
                                Frequently asked questions
                              </Typography>
                            </AnchorStyle>
                          </Box>

                          <Box sx={{ paddingLeft: '30px' }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'left', padding: 1 }}>
                              <img src="arrow.svg" alt="" />
                              <AnchorStyle href="#lifeAtNeko">
                                <Typography sx={{ padding: '0px 15px 0px 15px' }} >
                                  General Information
                                </Typography>
                              </AnchorStyle>
                            </Box>

                            <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'left', padding: 1 }}>
                              <img src="arrow.svg" alt="" />
                              <AnchorStyle href="#lifeAtNeko">
                                <Typography sx={{ padding: '0px 15px 0px 15px' }} >
                                  Presale Info
                                </Typography>
                              </AnchorStyle>
                            </Box>


                            <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'left', padding: 1 }}>
                              <img src="arrow.svg" alt="" />
                              <AnchorStyle href="#lifeAtNeko">
                                <Typography sx={{ padding: '0px 15px 0px 15px' }} >
                                  Contact us
                                </Typography>
                              </AnchorStyle>
                            </Box>
                          </Box>

                        </CardContent>


                      </Card>
                    </div>
                    {/* <Image
                      src="https://minimal-assets-api.vercel.app/assets/images/about/what-1.jpg"
                      ratio="3/4"
                      sx={{
                        borderRadius: 2,
                        boxShadow: shadow,
                      }}
                    /> */}
                  </MotionInView>
                </Grid>
              </Grid>
            </Grid>
          )}

          <Grid item xs={12} md={9} lg={8}>

            <MotionInView variants={varFade().inRight} id="about">
              <Typography
                variant="h2"
                sx={{ mb: 3, color: 'common.white' }} >
                About
              </Typography>
            </MotionInView>


            <MotionInView variants={varFade().inRight} sx={{
              color: 'common.white',
            }}>
              <Typography
                sx={{
                  mt: 2
                }}
              >
                At the quantum level, matter is just a collection of possibilities. The point at which reality becomes “real” can’t be pinned down. Everything exists in a state of potential.
              </Typography>
              <Typography
                sx={{
                  mt: 2
                }}
              >
                Enter the Nekoverse, where time, space, matter, and imagination collide to produce limitless possibilities. This top-down, open-ended social world is built on blockchain and maximizes the interactive and creative potential of the metaverse.
              </Typography>
              <Typography
                sx={{
                  mt: 2
                }}
              >
                Your mind-bending journey begins by minting your avatar, a Neko kitty inspired by Schrödinger’s cat, who teeters on an undefinable threshold between life and death.
              </Typography>
            </MotionInView>

            <MotionInView variants={varFade().inRight} id="lifeAtNeko">
              <Typography
                variant="h2"
                sx={{ mb: 3, mt: 10, color: 'common.white' }} >
                Start your life in the Nekotopia
              </Typography>
            </MotionInView>

            <MotionInView variants={varFade().inRight} sx={{
              color: 'common.white',
            }}>
              <Typography
                sx={{
                  mt: 2
                }}
              >
                Take a quantum leap into a new, multi-dimensional world. Mint your Neko and start exploring life in the Nekotopia, an endlessly unfolding metaverse of limitless possibilities.
              </Typography>
            </MotionInView>

            <MotionInView variants={varFade().inRight}>
              <Typography
                variant="h2"
                sx={{ mb: 3, mt: 10, color: 'common.white' }} >
                Frequently asked questions
              </Typography>
            </MotionInView>

            <MotionInView variants={varFade().inRight}>
              <AccordionStyle
                variant="p"
              >
                GENERAL
              </AccordionStyle>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <Typography>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <AccordionTitleStyle>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </AccordionTitleStyle>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <AccordionTitleStyle>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </AccordionTitleStyle>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <AccordionTitleStyle>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </AccordionTitleStyle>
                </AccordionDetails>
              </Accordion>
            </MotionInView>

            <MotionInView variants={varFade().inRight}>
              <AccordionStyle
                variant="p"
              >
                Presale info
              </AccordionStyle>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <AccordionTitleStyle>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </AccordionTitleStyle>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <AccordionTitleStyle>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</AccordionTitleStyle>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel3a-content"
                  id="panel3a-header"
                >
                  <AccordionTitleStyle>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</AccordionTitleStyle>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </MotionInView>

            <MotionInView variants={varFade().inRight}>
              <AccordionStyle
                variant="p"
              >
                support
              </AccordionStyle>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <AccordionTitleStyle>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</AccordionTitleStyle>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <AccordionTitleStyle>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</AccordionTitleStyle>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<Iconify icon={'eva:arrow-ios-downward-fill'} width={20} height={20} />}
                  aria-controls="panel3a-content"
                  id="panel3a-header"
                >
                  <AccordionTitleStyle>Condimentum mattis pellentesque id nibh tortor. Platea dictumst vestibulum</AccordionTitleStyle>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
                    malesuada lacus ex, sit amet blandit leo lobortis eget.
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </MotionInView>

            {/* <MotionInView variants={varFade().inRight}>
              <Typography
                variant="h2"
                sx={{ mb: 3, mt: 10, color: 'common.white' }} >
                General information
              </Typography>
            </MotionInView> */}



            {/* <MotionInView variants={varFade().inRight} sx={{
              color: 'common.white',
            }}>
              <Typography
                sx={{
                  mt: 2
                }}
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Tincidunt lobortis feugiat vivamus at augue eget. Congue mauris rhoncus aenean vel elit scelerisque. At erat pellentesque adipiscing commodo.
              </Typography>
              <Typography
                sx={{
                  mt: 2
                }}
              >
                Enim ut tellus elementum sagittis vitae et leo duis ut. Non arcu risus quis varius quam. Etiam non quam lacus suspendisse. Felis bibendum ut tristique et egestas. Pharetra diam sit amet nisl. Dictum fusce ut placerat orci nulla pellentesque dignissim. Vel pharetra vel turpis nunc eget. Est ullamcorper eget nulla facilisi etiam dignissim diam quis enim.
              </Typography>
            </MotionInView>

            <MotionInView variants={varFade().inRight} sx={{ mb: 3, mt: 10 }}>
              <CarouselBasic1 />
            </MotionInView>

            <MotionInView variants={varFade().inRight}>
              <Typography
                variant="h2"
                sx={{ mb: 3, mt: 10, color: 'common.white' }} >
                Minting
              </Typography>
            </MotionInView>

            <MotionInView variants={varFade().inRight} sx={{
              color: 'common.white',
            }}>
              <Typography
                sx={{
                  mt: 2
                }}
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Tincidunt lobortis feugiat vivamus at augue eget. Congue mauris rhoncus aenean vel elit scelerisque. At erat pellentesque adipiscing commodo.
              </Typography>
              <Typography
                sx={{
                  mt: 2
                }}
              >
                Enim ut tellus elementum sagittis vitae et leo duis ut. Non arcu risus quis varius quam. Etiam non quam lacus suspendisse. Felis bibendum ut tristique et egestas. Pharetra diam sit amet nisl. Dictum fusce ut placerat orci nulla pellentesque dignissim. Vel pharetra vel turpis nunc eget. Est ullamcorper eget nulla facilisi etiam dignissim diam quis enim.
              </Typography>
            </MotionInView> */}


          </Grid>
        </Grid>
      </Container>
    </RootStyle>
  );
}

// ----------------------------------------------------------------------

ProgressItem.propTypes = {
  progress: PropTypes.shape({
    label: PropTypes.string,
    value: PropTypes.number,
  }),
};

function ProgressItem({ progress }) {
  const { label, value } = progress;
  return (
    <Box sx={{ mt: 3 }}>
      <Box sx={{ mb: 1.5, display: 'flex', alignItems: 'center' }}>
        <Typography variant="subtitle2">{label}&nbsp;-&nbsp;</Typography>
        <Typography variant="body2" sx={{ color: 'text.secondary' }}>
          {fPercent(value)}
        </Typography>
      </Box>
      <LinearProgress
        variant="determinate"
        value={value}
        sx={{
          '& .MuiLinearProgress-bar': { bgcolor: 'grey.700' },
          '&.MuiLinearProgress-determinate': { bgcolor: 'divider' },
        }}
      />
    </Box>
  );
}

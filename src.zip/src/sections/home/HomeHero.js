import { m } from 'framer-motion';
import { Link as RouterLink } from 'react-router-dom';
// @mui
import { styled } from '@mui/material/styles';
import { Box, Link, Container, Typography, Stack } from '@mui/material';
// routes
import { PATH_DASHBOARD } from '../../routes/paths';
// components
import Image from '../../components/Image';
import Iconify from '../../components/Iconify';
import TextIconLabel from '../../components/TextIconLabel';
import { MotionContainer, varFade } from '../../components/animate';
import Button from '../../components/Button'
// ----------------------------------------------------------------------

const RootStyle = styled(m.div)(({ theme }) => ({
  position: 'relative',
  minHeight: '911px',
  overflow: 'hidden',
  // backgroundColor: theme.palette.grey[400],
  // [theme.breakpoints.up('md')]: {
  //   top: 0,
  //   left: 0,
  //   width: '100%',
  //   // height: '80vh',
  //   display: 'flex',
  //   // position: 'fixed',
  //   alignItems: 'center',
  // },
}));

const ContentStyle = styled((props) => <Stack spacing={5} {...props} />)(({ theme }) => ({
  zIndex: 10,
  // maxWidth: 450,
  // margin: 'auto',
  // marginTop: '80px',
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  textAlign: 'center',
  position: 'absolute',
  paddingTop: theme.spacing(25),
  paddingBottom: theme.spacing(15),
  [theme.breakpoints.up('md')]: {
    margin: 'unset',
    textAlign: 'center',
  },
}));

const HeroOverlayStyle = styled(m.img)({
  zIndex: 9,
  width: '100%',
  height: '100%',
  // objectFit: 'cover',
  position: 'absolute',
});

const HeroImgStyle = styled(m.img)(({ theme }) => ({
  position: 'absolute',
  top: '0',
  // left: '50%',
  zIndex: '1',
  // transform: 'translateX(-50 %)',
  width: '100%',
  height: 'auto'
}));

// const HeroBox = styled(Box)(({ theme }) => ({
//   minHeight: '911px',
//   overflow: 'hidden',
//   width: '100%'
// }));

// const HeroDividerStyle = styled('div')(({ theme }) => ({
//   // position: 'absolute',
//   // top: '700px',
//   // left: '0',
//   // zIndex: '1',
//   // width: '100 %',
//   // // minWidth: '1920px',
//   // height: 'auto',
//   // background: '#240e63'
//   // paddingTop: '216px',
//   position: 'relative',
//   zIndex: '2',
//   background: '#240e63 linear-gradient(180deg, #160E60 3.19%, rgba(22, 14, 96, 0) 100%)',
//   WebkitMask: 'url("second-slide.svg") center 0 no-repeat',
//   mask: 'url("second-slide.svg") center 0 no-repeat'
// }));


// ----------------------------------------------------------------------

export default function HomeHero() {
  return (
    // <MotionContainer>
    <RootStyle>
      {/* <HeroOverlayStyle
          alt="overlay"
        // src="https://minimal-assets-api.vercel.app/assets/overlay.svg"
        // variants={varFade().in}
        /> */}
      {/* <HeroBox> */}
      <HeroImgStyle
        alt="hero"
        src="main-bg.png"
        variants={varFade().inUp}
      />
      {/* </HeroBox> */}
      {/* <HeroDividerStyle
          alt="hero"
          src="second-slide.svg"
          variants={varFade().inUp}
        /> */}
      {/* <Container> */}
      <ContentStyle>
        <m.div variants={varFade().inRight}>
          <Typography variant="h3" sx={{ color: 'common.white' }}>
            An endlessly unfolding metaverse of limitless possibilities
          </Typography>
        </m.div>

        <m.div variants={varFade().inRight}>
          <Typography sx={{ color: 'common.white' }}>
            Take a quantum leap into a new, multi-dimensional world. Mint your Neko and start exploring life in the Nekoverse
          </Typography>
        </m.div>

        <m.div variants={varFade().inRight}>
          <Button
            handleClick={() => { }}
            sx={{
              marginRight: '40px',
              background: '#231447',
              '&:hover': {
                background: '#332171',
                boxShadow: '0 2px 19px rgb(103 65 197 / 36%)'
              }
            }}
          >
            White paper
          </Button>
          <Button
            handleClick={() => { }}
          >
            Register
          </Button>
        </m.div>

        {/* <Stack spacing={2.5}>
              <m.div variants={varFade().inRight}>
                <Typography variant="overline" sx={{ color: 'primary.light' }}>
                  Available For
                </Typography>
              </m.div>

              <Stack direction="row" spacing={1.5} justifyContent={{ xs: 'center', md: 'flex-start' }}>
                {['ic_sketch', 'ic_figma', 'ic_js', 'ic_ts', 'ic_nextjs'].map((resource) => (
                  <m.img
                    key={resource}
                    variants={varFade().inRight}
                    src={`https://minimal-assets-api.vercel.app/assets/images/home/${resource}.svg`}
                  />
                ))}
              </Stack>
            </Stack> */}
      </ContentStyle>
      {/* </Container> */}
    </RootStyle>
  );
}

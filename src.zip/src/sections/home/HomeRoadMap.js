import { m } from 'framer-motion';
import { Link as RouterLink } from 'react-router-dom';
// @mui
import { styled } from '@mui/material/styles';
import { Box, Link, Container, Typography, Stack, Grid } from '@mui/material';
// routes
import { PATH_DASHBOARD } from '../../routes/paths';
// components
import Image from '../../components/Image';
import Iconify from '../../components/Iconify';
import TextIconLabel from '../../components/TextIconLabel';
import { MotionContainer, varFade, MotionInView } from '../../components/animate';
import Button from '../../components/Button'
// ----------------------------------------------------------------------

const RootStyle = styled(m.div)(({ theme }) => ({
    position: 'relative',
    minHeight: '911px',
    overflow: 'hidden'
    // backgroundColor: theme.palette.grey[400],
    // [theme.breakpoints.up('md')]: {
    //   top: 0,
    //   left: 0,
    //   width: '100%',
    //   // height: '80vh',
    //   display: 'flex',
    //   // position: 'fixed',
    //   alignItems: 'center',
    // },
}));

const ContentStyle = styled('div')(({ theme }) => ({
    width: '100%',
    margin: '0 auto',
    maxWidth: '1578px',
    position: 'relative',
    padding: '0 30px',
    height: '1750px'
}));

const BoxStyle = styled(Box)({
    width: '210px',
    position: 'absolute',
    left: '50%',
    // top: '10%',
    zIndex: '2',
    fontWeight: '300',
    fontSize: '16px',
    lineHeight: '2',
    color: '#7c80b9',
    transform: 'translateX(-645px)',
    opacity: '0',
    transition: 'opacity .5s',
    transitionDelay: '.5s'
});

const HeroImgStyle = styled(m.img)(({ theme }) => ({
    // position: 'relative',
    // top: '0',
    // // left: '50%',
    // zIndex: '1',
    // width: '100%',
    // height: 'auto'
    width: '100%',
    position: 'absolute',
    top: '0',
    left: '50%',
    transform: 'translateX(-50%)',
    zIndex: '-1'
}));

const ImageStyle = styled(m.img)(({ theme }) => ({
    position: 'absolute',
    top: '60px',
    left: '50%',
    transform: 'translateX(-50%)',
    // left: '50%'
    // transform: translateX(-50 %);
    animation: 'road-map 1s linear infinite',
    '@keyframes road-map': {
        '0%': { strokeDashoffset: '0' },
        '100%': { strokeDashoffset: '-32px' }
    }
}));

// ----------------------------------------------------------------------

const RoadMapItem = ({ img, title, description, sx, imgsx, pinsx, textsx }) => {
    return (
        <Box
            sx={{
                width: '150px',
                position: 'absolute',
                textAlign: 'left',
                zIndex: '2',
                fontWeight: '300',
                fontSize: '16px',
                lineHeight: '2',
                color: '#7c80b9',
                ...sx
            }}>
            <Box sx={{
                position: 'absolute',
                ...imgsx,
            }}>
                <img src={img} alt="" />
            </Box>
            <Box sx={{
                top: '0',
                width: 'fit-content',
                position: 'absolute',
                ...pinsx
            }}>
                <img src="round-pin.svg" alt="" loading="lazy" />
            </Box>
            <Box sx={{
                fontWeight: '300',
                fontSize: '14px',
                // lineHeight: '2',
                color: '#7c80b9',
                ...textsx
            }}>
                <Box sx={{
                    fontWeight: 'bold',
                    fontSize: '30px',
                    // lineHeight: '35px',
                    color: '#fff',
                    // marginBottom: '10px',
                    whiteSpace: 'nowrap'
                }}>{title}</Box>
                {description}
            </Box>
        </Box >
    )
}

export default function HomeRoadMap() {
    return (
        // <MotionContainer>
        <RootStyle>
            <HeroImgStyle
                alt="hero"
                src="road-map.png"
                variants={varFade().inUp}
            />

            <ContentStyle sx={{ width: '100%' }}>
                <Container sx={{ color: 'common.white', textAlign: 'center' }}>
                    <m.div variants={varFade().inRight} >
                        <Typography variant="h2" component="div">
                            Road Map
                        </Typography>
                    </m.div>
                </Container>
                <ImageStyle src={"road-map.svg"} alt="" />
                {/* <Box sx={{}}> */}
                <RoadMapItem
                    img="roadMap/road-map1.png"
                    title="Aug-Sep 2021"
                    description="Idea assessment Team Building Project Planning Character Development Entity Structuring"
                    sx={{
                        width: '210px',
                        position: 'absolute',
                        left: '50%',
                        zIndex: '2',
                        transform: 'translateX(-632px)',
                        top: '259px'
                    }}
                    imgsx={{
                        top: '-190px',
                        left: '-40px'
                    }}
                    pinsx={{ left: '261px' }}
                />


                <RoadMapItem
                    img="roadMap/road-map2.png"
                    title="Sep - Oct 2021"
                    description="Whitepaper Website building Game Asset development"
                    sx={{
                        width: '210px',
                        position: 'absolute',
                        left: '50%',
                        zIndex: '2',
                        transform: 'translateX(-407px)',
                        top: '550px'
                    }}
                    imgsx={{
                        top: '-42px',
                        left: '-40px'
                    }}
                    pinsx={{ left: '271px' }}
                    textsx={{
                        position: 'absolute',
                        left: '185px',
                        top: '25px'
                    }}
                />


                <RoadMapItem
                    img="roadMap/road-map3.png"
                    title="Nov - Dec 2021"
                    description="Website Launch Whitepaper Launch Partnerships & Marketing"
                    sx={{
                        width: '210px',
                        position: 'absolute',
                        left: '50%',
                        zIndex: '2',
                        transform: 'translateX(399px)',
                        top: '514px'
                    }}
                    imgsx={{
                        top: '-207px',
                        left: '-40px'
                    }}
                    pinsx={{ left: '-51px' }}
                    textsx={{
                        position: 'absolute',
                        left: '8px',
                        top: '-23px'
                    }}
                />


                <RoadMapItem
                    img="roadMap/road-map4.png"
                    title="Dec-Jan 2022"
                    description="Seed and Private sales NFT Mint & IDO launch EA to Nekotopia Marketplace Launch"
                    sx={{
                        width: '210px',
                        position: 'absolute',
                        left: '50%',
                        zIndex: '2',
                        transform: 'translateX(236px)',
                        top: '866px'
                    }}
                    imgsx={{
                        top: '-55px',
                        left: '-40px'
                    }}
                    pinsx={{ left: '-51px' }}
                    textsx={{
                        position: 'absolute',
                        left: '171px',
                        top: '-23px'
                    }}
                />

                <RoadMapItem
                    img="roadMap/road-map5.png"
                    title="Jan-Feb 2022"
                    description="MOBA(P2E) Announcement Metaverse Testnet Staking & Swap Launch Neko Experiment Launch"
                    sx={{
                        width: '210px',
                        position: 'absolute',
                        left: '50%',
                        zIndex: '2',
                        transform: 'translateX(-211px)',
                        top: '1075px'
                    }}
                    imgsx={{
                        top: '-55px',
                        left: '-40px'
                    }}
                    pinsx={{ left: '-51px' }}
                    textsx={{
                        position: 'absolute',
                        left: '171px',
                        top: '-23px'
                    }}
                />

                <RoadMapItem
                    img="roadMap/road-map6.png"
                    title="Feb- March 2022"
                    description="MOBA Dev logs Nekotopia Patchwork MOBA Early Access"
                    sx={{
                        width: '210px',
                        position: 'absolute',
                        left: '50%',
                        zIndex: '2',
                        transform: 'translateX(-310px)',
                        top: '1333px'
                    }}
                    imgsx={{
                        top: '-55px',
                        left: '-40px'
                    }}
                    pinsx={{ left: '443px' }}
                    textsx={{
                        position: 'absolute',
                        left: '171px',
                        top: '-23px'
                    }}
                />


                <RoadMapItem
                    img="roadMap/road-map7.png"
                    title="March-April 2022"
                    description="Alpha Release of MOBA"
                    sx={{
                        width: '210px',
                        position: 'absolute',
                        left: '50%',
                        zIndex: '2',
                        transform: 'translateX(242px)',
                        top: '1621px'
                    }}
                    imgsx={{
                        top: '-124px',
                        left: '-40px'
                    }}
                    pinsx={{ left: '-51px' }}
                    textsx={{
                        position: 'absolute',
                        left: '-323px',
                        top: '-23px'
                    }}
                />

                {/* </Box> */}

                {/* <Grid container spacing={2} sx={{
                    position: 'absolute',
                    zIndex: "2"
                }} direction="row" justifyContent="space-around" alignItems="center">
                    <Grid item xs={7}>
                        <Box >

                            <MotionInView variants={varFade().inDown}>
                                <m.div animate={{ y: [0, 30, 0] }} transition={{ duration: 5, repeat: Infinity }}>
                                    <img src="cat.webp" alt="" width="80%" />
                                </m.div>
                            </MotionInView>
                        </Box>
                    </Grid>
                    <Grid item xs={4}>
                        <Box sx={{ padding: '0 15px 0 15px', textAlign: 'left' }}>
                            <MotionInView variants={varFade().inDown}>
                                <Typography variant="p">
                                    Take your Neko on an existential journey through space and time, exploring multiple aesthetic environments and styles of gameplay. Duke it out in the futuristic physics of the 3D MOBA. Travel back in time to the 32-bit era of video games for a spin on a Mario Kart-inspired racetrack. Test your agility and endurance with an infinite runner-style game.
                                    <br />
                                    <br />
                                    Dive into new worlds with game realms that include Radioactive, Digital, Punk, Quantum, Cosmos, and Abstract. Explore competitive edge and live operations, such as e-sports, events and tournaments, boss battles, mystery box and treasure chests, and professional team tie-ups.
                                </Typography>
                            </MotionInView>
                        </Box>
                    </Grid>
                </Grid> */}


                {/* <Box sx={{
                        position: 'absolute',
                    }}>
                        <MotionInView variants={varFade().inDown}>
                            Take your Neko on an existential journey through space and time, exploring multiple aesthetic environments and styles of gameplay. Duke it out in the futuristic physics of the 3D MOBA. Travel back in time to the 32-bit era of video games for a spin on a Mario Kart-inspired racetrack. Test your agility and endurance with an infinite runner-style game.
                        </MotionInView>
                    </Box>

                    <Box sx={{
                        position: 'absolute',
                    }}>
                        <MotionInView variants={varFade().inDown}>
                            Dive into new worlds with game realms that include Radioactive, Digital, Punk, Quantum, Cosmos, and Abstract. Explore competitive edge and live operations, such as e-sports, events and tournaments, boss battles, mystery box and treasure chests, and professional team tie-ups.                        
                            </MotionInView>
                    </Box> */}


            </ContentStyle>
        </RootStyle >
    );
}

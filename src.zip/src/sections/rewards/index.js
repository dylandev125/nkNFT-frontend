export { default as RewardHero } from './Hero';
export { default as YourRewards } from './YourRewards';
export { default as MileStoneRewards } from './MileStone'
export { default as Share } from './Share'
export { default as News } from './News'
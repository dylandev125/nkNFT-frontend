export { default as ComponentMUI } from './ComponentMUI';
export { default as ComponentHero } from './ComponentHero';
export { default as ComponentOther } from './ComponentExtra';
export { default as ComponentFoundation } from './ComponentFoundation';
